package com.example.frameworkapp.provider;

import android.support.v4.content.FileProvider;

/**
 * Created by jia.lu on 2017/8/11.
 */

public class MyFileProvider extends FileProvider {

}
